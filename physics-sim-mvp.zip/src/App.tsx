import React, { useMemo, useState } from 'react'
import SimulatorCanvas from './components/SimulatorCanvas'
import { World } from './engine/World'

export default function App() {
  const [world] = useState(() => new World())
  const [isPlaying, setIsPlaying] = useState(true)
  const [speed, setSpeed] = useState(1)

  const speeds = [0.1, 0.25, 0.5, 1, 2, 4, 8]

  return (
    <div className="app">
      <div className="menu">
        <button className="btn primary" onClick={() => setIsPlaying(p => !p)}>
          {isPlaying ? 'Pause' : 'Play'} (Space)
        </button>
        <button className="btn" onClick={() => { world.resetScene(); }}>
          Reset (Ctrl+R)
        </button>
        <label className="speedSelect">
          Speed:
          <select value={speed} onChange={(e) => setSpeed(parseFloat(e.target.value))}>
            {speeds.map(s => <option key={s} value={s}>{s}x</option>)}
          </select>
        </label>
        <div style={{marginLeft: 'auto'}} className="stat">
          t = {world.simTime.toFixed(2)} s · bodies = {world.bodies.length}
        </div>
      </div>
      <div className="palette">
        <div className="sectionTitle">Object Palette</div>
        <ToolButton label="Add Circle" onClick={() => world.spawnCircle()} />
        <ToolButton label="Add Box" onClick={() => world.spawnBox()} />
        <div className="sectionTitle">World</div>
        <NumberRow label="Gravity (m/s²)" min={-30} max={30} step={0.1} value={world.gravity.y} onChange={(v)=>{ world.gravity.y = v }} />
        <NumberRow label="Air Drag (b)" min={0} max={5} step={0.05} value={world.globalLinearDrag} onChange={(v)=>{ world.globalLinearDrag = v }} />
      </div>
      <div className="canvasWrap">
        <SimulatorCanvas world={world} isPlaying={isPlaying} speed={speed} />
      </div>
      <div className="props">
        <SelectionPanel world={world} />
      </div>
      <div className="graph">
        <div className="sectionTitle">Energy (sample)</div>
        <p className="stat">KE = {world.lastKE.toFixed(2)} J · PE = {world.lastPE.toFixed(2)} J · E = {(world.lastKE+world.lastPE).toFixed(2)} J</p>
        <p className="stat">Tip: drag bodies; release while playing to impart momentum.</p>
      </div>
    </div>
  )
}

function ToolButton({ label, onClick }: { label: string, onClick: ()=>void }) {
  return (
    <div className="toolCard" onClick={onClick} title={label}>
      <span>{label}</span>
      <span>+</span>
    </div>
  )
}

function NumberRow({ label, value, onChange, min, max, step }:{ label:string, value:number, onChange:(v:number)=>void, min:number, max:number, step:number }) {
  return (
    <div className="inputRow">
      <label style={{width: 140}}>{label}</label>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e)=>onChange(parseFloat(e.target.value))} />
      <input type="number" step={step} value={value} onChange={(e)=>onChange(parseFloat(e.target.value))} style={{width: 90}} />
    </div>
  )
}

function SelectionPanel({ world }:{ world: World }) {
  const sel = world.selection
  if (!sel) return <p className="stat">No selection. Click a body to select.</p>
  return (
    <div>
      <div className="sectionTitle">Selected Body</div>
      <div className="inputRow"><label style={{width:120}}>Type</label><span>{sel.shape.type}</span></div>
      <NumberRow label="Mass (kg)" min={0.1} max={100} step={0.1} value={sel.mass} onChange={(v)=>{ sel.setMass(v) }} />
      <NumberRow label="Restitution" min={0} max={1} step={0.05} value={sel.restitution} onChange={(v)=>{ sel.restitution = v }} />
      <NumberRow label="Friction (μk)" min={0} max={2} step={0.05} value={sel.friction} onChange={(v)=>{ sel.friction = v }} />
      <NumberRow label="Linear Drag (b)" min={0} max={5} step={0.05} value={sel.linearDrag} onChange={(v)=>{ sel.linearDrag = v }} />
      <div className="inputRow">
        <label style={{width:120}}>Static?</label>
        <input type="checkbox" checked={sel.isStatic} onChange={(e)=>{ sel.setStatic(e.target.checked) }} />
      </div>
      <div className="inputRow stat">pos=({sel.position.x.toFixed(2)}, {sel.position.y.toFixed(2)}) m</div>
      <div className="inputRow stat">vel=({sel.velocity.x.toFixed(2)}, {sel.velocity.y.toFixed(2)}) m/s</div>
    </div>
  )
}
