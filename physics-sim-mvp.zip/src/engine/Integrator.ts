import { Body } from './Body'
import { Vec2, V } from './Math2D'

export function integrateForces(b: Body, gravity: Vec2, dt: number) {
  if (b.isStatic || b.invMass === 0) return
  // Air drag: F = -b v
  const drag: Vec2 = { x: -b.linearDrag * b.velocity.x, y: -b.linearDrag * b.velocity.y }
  const total = { x: b.forceAcc.x + gravity.x * b.mass + drag.x, y: b.forceAcc.y + gravity.y * b.mass + drag.y }
  // a = F/m
  const ax = total.x * b.invMass
  const ay = total.y * b.invMass
  // semi-implicit euler
  b.velocity.x += ax * dt
  b.velocity.y += ay * dt
}

export function integrateVelocity(b: Body, dt: number) {
  if (b.isStatic || b.invMass === 0) return
  b.position.x += b.velocity.x * dt
  b.position.y += b.velocity.y * dt
  // clear forces
  b.forceAcc.x = 0; b.forceAcc.y = 0
}
