export type ShapeType = 'Circle' | 'Box'

export interface Shape {
  type: ShapeType
}
export class Circle implements Shape {
  type: ShapeType = 'Circle'
  radius: number
  constructor(radius: number) { this.radius = radius }
}
export class Box implements Shape {
  type: ShapeType = 'Box'
  hw: number; hh: number // half-widths in meters
  constructor(width: number, height: number) { this.hw = width/2; this.hh = height/2 }
}
