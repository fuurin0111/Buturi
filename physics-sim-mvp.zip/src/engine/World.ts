import { Body } from './Body'
import { Circle, Box } from './Shapes'
import { Vec2 } from './Math2D'
import * as Integrator from './Integrator'
import * as Collision from './Collision'

const STEP = 1/120 // 120 Hz physics
const MAX_ACCUM = 0.25 // cap to avoid spiral of death
export const PX_PER_M = 100 // rendering scale

export class World {
  bodies: Body[] = []
  gravity: Vec2 = { x: 0, y: 9.81 } // m/s^2 downward (screen y+ is down)
  globalLinearDrag: number = 0.0
  simTime = 0
  selection: Body | null = null
  lastKE = 0
  lastPE = 0

  private acc = 0 // accumulator seconds

  stepFrame(dtReal: number, timeScale: number){
    const dtScaled = Math.min(dtReal * timeScale, MAX_ACCUM)
    this.acc += dtScaled
    while (this.acc >= STEP) {
      this.singleStep(STEP)
      this.acc -= STEP
      this.simTime += STEP
    }
  }

  singleStep(dt: number){
    // Apply global linear drag to each body
    for (const b of this.bodies) {
      b.linearDrag = Math.max(0, this.globalLinearDrag)
    }
    // Integrate forces and velocities
    for (const b of this.bodies) Integrator.integrateForces(b, this.gravity, dt)

    // Detect & resolve collisions (naive N^2)
    const n = this.bodies.length
    for (let i=0;i<n;i++){
      for (let j=i+1;j<n;j++){
        const a = this.bodies[i], b = this.bodies[j]
        const m = Collision.detect(a,b)
        if (m) Collision.resolve(m)
      }
    }
    for (const b of this.bodies) Integrator.integrateVelocity(b, dt)

    // energy bookkeeping (for display)
    this.computeEnergies()
  }

  computeEnergies(){
    let KE=0, PE=0
    for (const b of this.bodies) {
      if (b.invMass===0) continue
      KE += 0.5 * b.mass * (b.velocity.x*b.velocity.x + b.velocity.y*b.velocity.y)
      // choose y=0 at top of canvas; approximate PE = m g y (in meters)
      const y = b.position.y
      PE += b.mass * this.gravity.y * y
    }
    this.lastKE = KE
    this.lastPE = PE
  }

  resetScene(){
    this.bodies = []
    this.simTime = 0
    this.acc = 0
    this.selection = null
    // floor & walls (static boxes) for convenience
    const floor = new Body(new Box(12, 0.5), 0); floor.setStatic(true); floor.position = {x: 6, y: 7.5}
    const left = new Body(new Box(0.5, 8), 0); left.setStatic(true); left.position = {x: 0.25, y: 4}
    const right = new Body(new Box(0.5, 8), 0); right.setStatic(true); right.position = {x: 11.75, y: 4}
    this.bodies.push(floor,left,right)
    // a couple of sample bodies
    const c = new Body(new Circle(0.3), 2); c.position = {x:2,y:1}; c.restitution=0.6; c.friction=0.3; c.color='#ff4444'
    const b = new Body(new Box(0.6,0.6), 3); b.position = {x:4,y:1}; b.restitution=0.3; b.friction=0.6; b.color='#44cc44'
    this.bodies.push(c,b)
  }

  constructor(){
    this.resetScene()
  }

  spawnCircle(){
    const c = new Body(new Circle(0.25 + Math.random()*0.25), 1 + Math.random()*4)
    c.position = { x: 1 + Math.random()*4, y: 1 }
    c.restitution = 0.5; c.friction = 0.3; c.color = '#4488ff'
    this.bodies.push(c)
  }
  spawnBox(){
    const w = 0.4 + Math.random()*0.4, h = 0.4 + Math.random()*0.4
    const b = new Body(new Box(w, h), 1 + Math.random()*4)
    b.position = { x: 6 + Math.random()*4, y: 1 }
    b.restitution = 0.3; b.friction = 0.6; b.color = '#ffaa33'
    this.bodies.push(b)
  }
}
