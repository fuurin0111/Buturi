import { Vec2, V } from './Math2D'
import { Shape, Circle, Box } from './Shapes'

export class Body {
  shape: Shape
  position: Vec2 = { x: 0, y: 0 } // meters
  velocity: Vec2 = { x: 0, y: 0 } // m/s
  forceAcc: Vec2 = { x: 0, y: 0 }  // N
  mass: number
  invMass: number
  restitution: number = 0.6
  friction: number = 0.2       // kinetic μk (used in collision response)
  linearDrag: number = 0.0     // b in F=-b v
  isStatic: boolean = false
  color: string = '#4488ff'

  constructor(shape: Shape, mass: number) {
    this.shape = shape
    this.mass = mass
    this.invMass = (mass > 0) ? 1/mass : 0
  }

  setMass(m:number){
    this.mass = Math.max(0.0001, m)
    this.invMass = this.isStatic ? 0 : 1/this.mass
  }
  setStatic(s:boolean){
    this.isStatic = s
    this.invMass = s ? 0 : 1/Math.max(0.0001, this.mass)
    if (s) this.velocity = {x:0,y:0}
  }
  applyForce(F:Vec2){ this.forceAcc = V.add(this.forceAcc, F) }
}
