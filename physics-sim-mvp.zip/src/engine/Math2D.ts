export type Vec2 = { x: number; y: number }
export const V = {
  add:(a:Vec2,b:Vec2):Vec2=>({x:a.x+b.x,y:a.y+b.y}),
  sub:(a:Vec2,b:Vec2):Vec2=>({x:a.x-b.x,y:a.y-b.y}),
  mul:(a:Vec2,s:number):Vec2=>({x:a.x*s,y:a.y*s}),
  dot:(a:Vec2,b:Vec2):number=>a.x*b.x + a.y*b.y,
  len2:(a:Vec2):number=>a.x*a.x + a.y*a.y,
  len:(a:Vec2):number=>Math.hypot(a.x,a.y),
  norm:(a:Vec2):Vec2=>{ const l = Math.hypot(a.x,a.y)||1; return {x:a.x/l,y:a.y/l} },
  clamp:(v:number, min:number, max:number)=>Math.max(min, Math.min(max, v)),
}
