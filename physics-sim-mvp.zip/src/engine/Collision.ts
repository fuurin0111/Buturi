import { Body } from './Body'
import { Circle, Box } from './Shapes'
import { Vec2, V } from './Math2D'

export interface Manifold {
  a: Body; b: Body;
  normal: Vec2; // from a to b
  penetration: number;
  contact: Vec2;
}

export function detect(a: Body, b: Body): Manifold | null {
  if (a.isStatic && b.isStatic) return null
  if (a.shape instanceof Circle && b.shape instanceof Circle) return circleCircle(a,b)
  if (a.shape instanceof Circle && b.shape instanceof Box) return circleAABB(a,b)
  if (a.shape instanceof Box && b.shape instanceof Circle) {
    const m = circleAABB(b,a)
    if (!m) return null
    return { a, b, normal: V.mul(m.normal,-1), penetration: m.penetration, contact: m.contact }
  }
  if (a.shape instanceof Box && b.shape instanceof Box) return aabbAabb(a,b)
  return null
}

function circleCircle(a:Body, b:Body): Manifold | null {
  const sa = a.shape as Circle
  const sb = b.shape as Circle
  const delta = V.sub(b.position, a.position)
  const dist2 = V.len2(delta)
  const r = sa.radius + sb.radius
  if (dist2 > r*r) return null
  const dist = Math.sqrt(dist2) || 1e-8
  const normal = V.mul(delta, 1/dist)
  const penetration = r - dist
  const contact = V.add(a.position, V.mul(normal, (sa.radius - penetration/2)))
  return { a,b, normal, penetration, contact }
}

function circleAABB(ac:Body, bb:Body): Manifold | null {
  const c = ac.shape as Circle
  const b = bb.shape as Box
  const rel = V.sub(ac.position, bb.position)
  const closest: Vec2 = {
    x: V.clamp(rel.x, -b.hw, b.hw),
    y: V.clamp(rel.y, -b.hh, b.hh),
  }
  const closestWorld = { x: bb.position.x + closest.x, y: bb.position.y + closest.y }
  const delta = V.sub(ac.position, closestWorld)
  const d2 = V.len2(delta)
  if (d2 > c.radius*c.radius) return null
  const dist = Math.sqrt(d2) || 1e-8
  const normal = dist < 1e-6 ? {x:0,y:-1} : V.mul(delta, 1/dist)
  const penetration = c.radius - dist
  const contact = closestWorld
  return { a: ac, b: bb, normal, penetration, contact }
}

function aabbAabb(a:Body, b:Body): Manifold | null {
  const A = a.shape as Box
  const B = b.shape as Box
  const dx = b.position.x - a.position.x
  const px = (A.hw + B.hw) - Math.abs(dx)
  if (px <= 0) return null
  const dy = b.position.y - a.position.y
  const py = (A.hh + B.hh) - Math.abs(dy)
  if (py <= 0) return null
  // collision; choose axis of minimum penetration
  if (px < py) {
    const normal = { x: dx < 0 ? -1 : 1, y: 0 }
    return { a, b, normal, penetration: px, contact: { x: (a.position.x + b.position.x)/2, y: (a.position.y + b.position.y)/2 } }
  } else {
    const normal = { x: 0, y: dy < 0 ? -1 : 1 }
    return { a, b, normal, penetration: py, contact: { x: (a.position.x + b.position.x)/2, y: (a.position.y + b.position.y)/2 } }
  }
}

export function resolve(m: Manifold){
  const { a, b, normal, penetration } = m
  const invMassSum = a.invMass + b.invMass
  if (invMassSum === 0) return

  // Positional correction (to prevent sinking)
  const percent = 0.8 // penetration percentage to correct
  const slop = 0.001
  const correctionMag = Math.max(penetration - slop, 0) * percent / invMassSum
  const correction = { x: normal.x * correctionMag, y: normal.y * correctionMag }
  if (!a.isStatic) a.position = { x: a.position.x - correction.x * a.invMass, y: a.position.y - correction.y * a.invMass }
  if (!b.isStatic) b.position = { x: b.position.x + correction.x * b.invMass, y: b.position.y + correction.y * b.invMass }

  // Relative velocity
  const rv = { x: b.velocity.x - a.velocity.x, y: b.velocity.y - a.velocity.y }
  const velAlongNormal = rv.x*normal.x + rv.y*normal.y
  if (velAlongNormal > 0) return // separating

  // Restitution
  const e = Math.min(a.restitution, b.restitution)

  // Normal impulse scalar
  const j = -(1 + e) * velAlongNormal / invMassSum
  const impulse = { x: normal.x * j, y: normal.y * j }

  if (!a.isStatic) a.velocity = { x: a.velocity.x - impulse.x * a.invMass, y: a.velocity.y - impulse.y * a.invMass }
  if (!b.isStatic) b.velocity = { x: b.velocity.x + impulse.x * b.invMass, y: b.velocity.y + impulse.y * b.invMass }

  // Tangential (friction)
  const rv2 = { x: b.velocity.x - a.velocity.x, y: b.velocity.y - a.velocity.y }
  const tUn = { x: rv2.x - velAlongNormal*normal.x, y: rv2.y - velAlongNormal*normal.y }
  const tLen = Math.hypot(tUn.x, tUn.y) || 1
  const tangent = { x: tUn.x / tLen, y: tUn.y / tLen }
  const jt = -(rv2.x*tangent.x + rv2.y*tangent.y) / invMassSum
  const mu = Math.sqrt(a.friction * b.friction) // combine
  const maxFriction = j * mu
  const jtClamped = Math.max(-maxFriction, Math.min(maxFriction, jt))
  const fImpulse = { x: tangent.x * jtClamped, y: tangent.y * jtClamped }
  if (!a.isStatic) a.velocity = { x: a.velocity.x - fImpulse.x * a.invMass, y: a.velocity.y - fImpulse.y * a.invMass }
  if (!b.isStatic) b.velocity = { x: b.velocity.x + fImpulse.x * b.invMass, y: b.velocity.y + fImpulse.y * b.invMass }
}
