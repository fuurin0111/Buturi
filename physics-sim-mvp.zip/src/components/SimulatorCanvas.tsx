import React, { useEffect, useRef, useState } from 'react'
import { World, PX_PER_M } from '../engine/World'
import { Body } from '../engine/Body'
import { Circle, Box } from '../engine/Shapes'

function useAnimLoop(cb: (dt: number)=>void, deps: any[]){
  const lastRef = useRef<number>(performance.now())
  useEffect(()=>{
    let raf = 0
    function loop(t:number){
      const last = lastRef.current
      let dt = (t - last)/1000
      lastRef.current = t
      cb(dt)
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
}

export default function SimulatorCanvas({ world, isPlaying, speed }:{ world:World, isPlaying:boolean, speed:number }){
  const ref = useRef<HTMLCanvasElement>(null)
  const [hoverId, setHoverId] = useState<number | null>(null)
  const [drag, setDrag] = useState<{ id:number, prev:{x:number,y:number} }|null>(null)

  useAnimLoop((dt)=>{
    if (isPlaying) world.stepFrame(dt, speed)
    const ctx = ref.current?.getContext('2d')
    if (!ctx || !ref.current) return
    const W = ref.current.width = ref.current.clientWidth
    const H = ref.current.height = ref.current.clientHeight
    drawGrid(ctx, W, H)
    drawWorld(ctx, world, hoverId)
  }, [world, isPlaying, speed, hoverId])

  // Mouse interactions
  useEffect(()=>{
    const el = ref.current!
    function toWorld(evt: MouseEvent){
      const r = el.getBoundingClientRect()
      const x = (evt.clientX - r.left) / PX_PER_M
      const y = (evt.clientY - r.top) / PX_PER_M
      return { x, y }
    }
    function onMove(e:MouseEvent){
      const p = toWorld(e)
      if (drag){
        const b = world.bodies[drag.id]
        const dx = (p.x - drag.prev.x), dy = (p.y - drag.prev.y)
        b.position.x += dx; b.position.y += dy
        // velocity for momentum on release is computed relative to time; here approximate using 1/60
        b.velocity.x = dx * 60
        b.velocity.y = dy * 60
        drag.prev = p
        setDrag({...drag})
        return
      }
      // hover detection (simple id via index and distance)
      let hid: number | null = null
      world.bodies.forEach((b, i)=>{
        if (pointInBody(p.x, p.y, b)) hid = i
      })
      setHoverId(hid)
    }
    function onDown(e:MouseEvent){
      const p = toWorld(e)
      for (let i=world.bodies.length-1; i>=0; i--){
        const b = world.bodies[i]
        if (pointInBody(p.x, p.y, b)){
          world.selection = b
          setDrag({ id:i, prev:p })
          break
        }
      }
    }
    function onUp(){
      setDrag(null)
    }
    el.addEventListener('mousemove', onMove)
    el.addEventListener('mousedown', onDown)
    window.addEventListener('mouseup', onUp)
    return ()=>{
      el.removeEventListener('mousemove', onMove)
      el.removeEventListener('mousedown', onDown)
      window.removeEventListener('mouseup', onUp)
    }
  }, [world, drag])

  // keyboard shortcuts
  useEffect(()=>{
    function onKey(e:KeyboardEvent){
      if (e.code === 'Space'){ e.preventDefault() }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase()==='r'){ e.preventDefault(); world.resetScene() }
    }
    window.addEventListener('keydown', onKey)
    return ()=> window.removeEventListener('keydown', onKey)
  }, [world])

  return <canvas ref={ref} style={{width:'100%', height:'100%'}} />
}

function drawGrid(ctx:CanvasRenderingContext2D, W:number, H:number){
  ctx.clearRect(0,0,W,H)
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0,0,W,H)
  ctx.strokeStyle = '#e5e5e5'
  ctx.lineWidth = 1
  const step = 1 * PX_PER_M
  ctx.beginPath()
  for (let x=0; x<=W; x+=step){ ctx.moveTo(x,0); ctx.lineTo(x,H) }
  for (let y=0; y<=H; y+=step){ ctx.moveTo(0,y); ctx.lineTo(W,y) }
  ctx.stroke()
}

function drawWorld(ctx:CanvasRenderingContext2D, world:World, hoverId:number|null){
  world.bodies.forEach((b,i)=>{
    ctx.save()
    const x = b.position.x * PX_PER_M
    const y = b.position.y * PX_PER_M
    // body
    ctx.globalAlpha = 1
    ctx.fillStyle = b.color
    ctx.strokeStyle = '#00ffff'
    ctx.lineWidth = (world.selection===b || hoverId===i) ? 3 : 1
    if (b.shape instanceof Circle){
      ctx.beginPath()
      ctx.arc(x, y, b.shape.radius * PX_PER_M, 0, Math.PI*2)
      ctx.fill()
      if (world.selection===b || hoverId===i) ctx.stroke()
    } else if (b.shape instanceof Box){
      const hw = b.shape.hw * PX_PER_M, hh = b.shape.hh * PX_PER_M
      ctx.beginPath()
      ctx.rect(x - hw, y - hh, hw*2, hh*2)
      ctx.fill()
      if (world.selection===b || hoverId===i) ctx.stroke()
    }
    // velocity vector
    ctx.beginPath()
    ctx.strokeStyle = '#00ff00'
    ctx.lineWidth = 2
    ctx.moveTo(x,y)
    ctx.lineTo(x + b.velocity.x * PX_PER_M * 0.1, y + b.velocity.y * PX_PER_M * 0.1)
    ctx.stroke()
    ctx.restore()
  })
}

function pointInBody(x:number,y:number,b:Body){
  if (b.shape instanceof Circle){
    const dx = x - b.position.x, dy = y - b.position.y
    return (dx*dx + dy*dy) <= b.shape.radius*b.shape.radius
  } else if (b.shape instanceof Box){
    return Math.abs(x - b.position.x) <= b.shape.hw && Math.abs(y - b.position.y) <= b.shape.hh
  }
  return false
}
