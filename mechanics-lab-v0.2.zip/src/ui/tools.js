export function setupTools(engine) {
  const palette = document.getElementById('palette');
  const canvas = document.getElementById('world');
  let currentTool = 'point';
  palette.addEventListener('click', (e) => {
    const it = e.target.closest('.palette-item'); if (it) currentTool = it.dataset.tool;
  });

  let hover = null;
  canvas.addEventListener('mousemove', (e) => {
    const r = canvas.getBoundingClientRect(); const x = e.clientX - r.left, y = e.clientY - r.top;
    hover = engine.pick(x,y);
  });
  canvas.addEventListener('mousedown', (e) => {
    if (e.button === 0 && currentTool === 'force' && hover) {
      // start a drag to set force vector
      const r = canvas.getBoundingClientRect(); const x0 = e.clientX - r.left, y0 = e.clientY - r.top;
      function move(ev) {
        const x1 = ev.clientX - r.left, y1 = ev.clientY - r.top;
        drawPreview(x0,y0,x1,y1);
      }
      function up(ev) {
        const x1 = ev.clientX - r.left, y1 = ev.clientY - r.top;
        cleanup();
        const Fx = (x1-x0)*0.5, Fy = (y1-y0)*0.5;
        engine.addAppliedForce({ body: hover, point: hover.position, mode: 'constant', Fx, Fy, duration: 0.3, timeLeft: 0.3 });
      }
      function cleanup(){ window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); clearPreview(); }
      window.addEventListener('mousemove', move); window.addEventListener('mouseup', up);
    }
  });

  // simple overlay canvas for previews
  const overlay = document.createElement('canvas'); overlay.width = canvas.width; overlay.height = canvas.height; overlay.style.position='absolute'; overlay.style.left='0'; overlay.style.top='0'; overlay.style.pointerEvents='none';
  canvas.parentElement.appendChild(overlay);
  const octx = overlay.getContext('2d');
  function drawPreview(x0,y0,x1,y1){ clearPreview(); octx.beginPath(); octx.moveTo(x0,y0); octx.lineTo(x1,y1); octx.strokeStyle='#ffd166'; octx.lineWidth=2; octx.stroke(); }
  function clearPreview(){ octx.clearRect(0,0,overlay.width,overlay.height); }
}
