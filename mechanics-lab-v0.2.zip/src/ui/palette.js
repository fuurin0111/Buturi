export function buildPalette(engine) {
  const el = document.getElementById('palette');
  el.innerHTML = `
    <div class="title" data-i18n="palette">Object Palette</div>
    <div class="palette-grid">
      ${item('⚪', 'Point Mass', 'point')}
      ${item('▭', 'Box', 'box')}
      ${item('╲', 'Inclined Plane', 'incline')}
      ${item('🌀', 'Spring', 'spring')}
      ${item('⏺️', 'Pendulum', 'pendulum')}
      ${item('➡️', 'Force Tool', 'force')}
    </div>
    <div style="margin-top:.5rem; color:#8aa0b5; font-size:.9rem;">Double-click canvas to spawn with selected tool.</div>
  `;

  el.addEventListener('click', (e) => {
    const it = e.target.closest('.palette-item');
    if (!it) return;
    el.querySelectorAll('.palette-item').forEach(n => n.classList.remove('selected'));
    it.classList.add('selected');
  });
  // default selection
  el.querySelector('.palette-item').classList.add('selected');

  const canvas = document.getElementById('world');
  canvas.addEventListener('dblclick', (e) => {
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const tool = el.querySelector('.palette-item.selected')?.dataset.tool || 'point';
    spawn(tool, x, y);
  });

  function spawn(tool, x, y) {
    switch (tool) {
      case 'point': engine.addCircle(x, y, 18, 1); break;
      case 'box': engine.addBox(x, y, 80, 40, 2); break;
      case 'incline': engine.addInclined(x, y, 260, 14, Math.PI/9); break;
      case 'spring': {
        const bs = engine.state.bodies.slice(-2); if (bs.length===2) engine.addSpring(bs[0], bs[1], { k: 200, length: 180, damping: 5 });
        break;
      }
      case 'pendulum': engine.addPendulum(x, y, 180, 1); break;
      case 'force': {
        // create a small invisible helper? The actual application is in tools.js via drag on a body.
        break;
      }
    }
  }

  function item(icon, label, tool) {
    return `<div class="palette-item" data-tool="${tool}">
      <div class="icon">${icon}</div><div class="label">${label}</div>
    </div>`;
  }
}
