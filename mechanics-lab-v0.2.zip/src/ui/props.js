export function buildProps(engine) {
  const el = document.getElementById('props');
  render(null);
  window.addEventListener('selection', e => render(e.detail));

  function render(body) {
    el.innerHTML = `
      <div class="title" data-i18n="properties">Properties</div>
      ${!body ? '<div class="muted">Select an object…</div>' : bodyUI(body)}
    `;
    if (!body) return;

    const mass = el.querySelector('#mass');
    const rest = el.querySelector('#restitution');
    const fric = el.querySelector('#friction');
    const fricS = el.querySelector('#frictionStatic');
    const lock = el.querySelector('#lock');
    const del = el.querySelector('#delete');

    mass.addEventListener('input', () => engine.setMass(body, parseFloat(mass.value)));
    rest.addEventListener('input', () => body.restitution = parseFloat(rest.value));
    fric.addEventListener('input', () => body.friction = parseFloat(fric.value));
    fricS.addEventListener('input', () => body.frictionStatic = parseFloat(fricS.value));
    lock.addEventListener('change', () => body.isStatic = lock.checked);
    del.addEventListener('click', () => { Matter.World.remove(engine.world, body); const i=engine.state.bodies.indexOf(body); if(i>=0) engine.state.bodies.splice(i,1); window.dispatchEvent(new CustomEvent('selection', { detail: null })); render(null); });
  }

  function bodyUI(b) {
    return `
      <div class="prop-group">
        <div class="prop"><span>Mass (kg)</span><input id="mass" type="number" min="0.1" max="100" step="0.1" value="${b.mass.toFixed(2)}"></div>
        <div class="prop"><span>Restitution</span><input id="restitution" type="range" min="0" max="1" step="0.01" value="${b.restitution ?? 0.4}"></div>
        <div class="prop"><span>Friction</span><input id="friction" type="range" min="0" max="2" step="0.01" value="${b.friction ?? 0.3}"></div>
        <div class="prop"><span>Static Friction</span><input id="frictionStatic" type="range" min="0" max="2" step="0.01" value="${b.frictionStatic ?? 0.6}"></div>
        <div class="prop"><span>Fixed (Immovable)</span><input id="lock" type="checkbox" ${b.isStatic?'checked':''}></div>
        <div class="prop"><button id="delete" class="button" style="border-color:#5a2a2a">Delete</button></div>
      </div>
    `;
  }
}
