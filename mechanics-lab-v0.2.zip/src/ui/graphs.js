export function setupGraphs(engine) {
  const cE = document.getElementById('graphEnergy').getContext('2d');
  const cP = document.getElementById('graphPos').getContext('2d');
  const cV = document.getElementById('graphVel').getContext('2d');
  const tabs = document.querySelectorAll('.tab');
  const wraps = document.querySelectorAll('.graph-wrap');
  tabs.forEach(t => t.addEventListener('click', () => {
    tabs.forEach(a=>a.classList.remove('active')); t.classList.add('active');
    wraps.forEach(w => w.classList.toggle('hidden', w.dataset.tab !== t.dataset.tab));
  }));

  const energy = [];
  const pos = []; // track first body x,y
  const vel = []; // track first body vx,vy

  function sample(t) {
    const e = engine.computeEnergies(); energy.push({ t, ...e }); if (energy.length>3000) energy.shift();
    const b = engine.state.bodies[0];
    if (b) {
      pos.push({ t, x: b.position.x, y: b.position.y }); if (pos.length>3000) pos.shift();
      vel.push({ t, vx: b.velocity.x, vy: b.velocity.y }); if (vel.length>3000) vel.shift();
    }
  }

  function drawLine(ctx, arr, getY, label) {
    const width = ctx.canvas.width = ctx.canvas.clientWidth;
    const height = ctx.canvas.height = ctx.canvas.clientHeight;
    ctx.clearRect(0,0,width,height);
    if (arr.length < 2) return;
    const tmin = Math.max(0, arr[arr.length-1].t - 20);
    const tmax = arr[arr.length-1].t;
    const sub = arr.filter(p => p.t >= tmin);
    const ymin = Math.min(...sub.map(getY));
    const ymax = Math.max(...sub.map(getY));
    const px = v => (v - tmin) / (tmax - tmin || 1) * (width - 40) + 30;
    const py = v => height - 20 - (v - ymin) / (ymax - ymin || 1) * (height - 40);
    // axes
    ctx.strokeStyle = '#789'; ctx.beginPath(); ctx.moveTo(30,10); ctx.lineTo(30,height-20); ctx.lineTo(width-10,height-20); ctx.stroke();
    // line
    ctx.beginPath();
    sub.forEach((p,i)=> { const x = px(p.t), y = py(getY(p)); if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y); });
    ctx.strokeStyle = '#9ab'; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = '#9ab'; ctx.fillText(label, 40, 18);
  }

  function draw() {
    drawLine(cE, energy, p => p.TE, 'Total Energy');
    drawLine(cP, pos, p => p.y, 'y(t) (px)');
    drawLine(cV, vel, p => p.vx, 'vx(t) (px/s)');
  }

  function reset() { energy.length = 0; pos.length = 0; vel.length = 0; }

  function exportCSV() {
    const lines = ['t,KE,PE,TE,x,y,vx,vy'];
    const len = Math.max(energy.length, pos.length, vel.length);
    for (let i=0;i<len;i++) {
      const e = energy[i] || {}; const p = pos[i] || {}; const v = vel[i] || {};
      lines.push(`${e.t ?? ''},${e.KE ?? ''},${e.PE ?? ''},${e.TE ?? ''},${p.x ?? ''},${p.y ?? ''},${v.vx ?? ''},${v.vy ?? ''}`);
    }
    const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'mechlab_graphs.csv'; a.click();
  }

  return { sample, draw, reset, exportCSV };
}
