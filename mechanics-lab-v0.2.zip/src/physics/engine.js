// Matter.js wrapper with educational helpers + trails, vectors, templates, drag modes
const { Engine, World, Bodies, Body, Composite, Constraint, Events, Vector } = Matter;

export function createEngine(canvas, opts) {
  const pixelsPerMeter = opts.pixelsPerMeter || 100;
  const engine = Engine.create();
  engine.gravity.y = 0; // we'll apply our own gravity force
  const world = engine.world;

  const state = {
    ppm: pixelsPerMeter,
    bodies: [],
    constraints: [],
    selected: null,
    g: 9.81,
    dragMode: 'off', // 'off'|'linear'|'quadratic'
    showVectors: true,
    showTrails: true,
    trailEvery: 10,
    trailTick: 0,
    trails: new Map(),
    zeroPEy: canvas.height - 10
  };

  // walls
  const pad = 2000;
  const walls = [
    Bodies.rectangle(-pad, canvas.height/2, 20, canvas.height*10, { isStatic: true }),
    Bodies.rectangle(canvas.width+pad, canvas.height/2, 20, canvas.height*10, { isStatic: true }),
    Bodies.rectangle(canvas.width/2, canvas.height+pad, canvas.width*10, 20, { isStatic: true }),
    Bodies.rectangle(canvas.width/2, -pad, canvas.width*10, 20, { isStatic: true }),
  ];
  World.add(world, walls);

  function setMass(body, massKg) {
    const area = body.area || 1;
    const density = massKg / area;
    Body.setDensity(body, density);
  }

  function addCircle(x, y, r=20, mass=1, options={}) {
    const body = Bodies.circle(x, y, r, Object.assign({ restitution: 0.5, friction: 0.2, frictionStatic: 0.5 }, options));
    setMass(body, mass);
    World.add(world, body); state.bodies.push(body);
    return body;
  }
  function addBox(x, y, w=80, h=40, mass=2, options={}) {
    const body = Bodies.rectangle(x, y, w, h, Object.assign({ restitution: 0.4, friction: 0.3, frictionStatic: 0.6 }, options));
    setMass(body, mass);
    World.add(world, body); state.bodies.push(body);
    return body;
  }
  function addInclined(x, y, w=300, h=14, angleRad=Math.PI/8, options={}) {
    const body = Bodies.rectangle(x, y, w, h, Object.assign({ isStatic:true, angle: angleRad, friction: 0.5, frictionStatic: 0.8 }, options));
    World.add(world, body);
    return body;
  }
  function addPendulum(px, py, length=200, mass=1) {
    const pivot = { x: px, y: py };
    const bob = addCircle(px, py + length, 18, mass);
    const rod = Constraint.create({ pointA: pivot, bodyB: bob, length, stiffness: 1, damping: 0.0 });
    World.add(world, rod); state.constraints.push(rod);
    return { pivot, bob, rod };
  }
  function addSpring(bodyA, bodyB, opts={}) {
    const c = Constraint.create({
      bodyA, bodyB,
      pointA: opts.pointA || {x:0,y:0},
      pointB: opts.pointB || {x:0,y:0},
      length: opts.length ?? 160,
      stiffness: Math.min(1, Math.max(0.0001, (opts.k ?? 100) / 1000)),
      damping: Math.min(1, (opts.damping ?? 0) / 50)
    });
    World.add(world, c); state.constraints.push(c); return c;
  }

  // Applied forces (tool-managed)
  const appliedForces = []; // { body, point, mode:'constant'|'impulse', Fx,Fy, duration, timeLeft }
  function applyForces(dt) {
    for (const b of state.bodies) {
      if (b.isStatic) continue;
      // gravity
      Body.applyForce(b, b.position, { x: 0, y: b.mass * state.g / 60 });
      // drag
      if (state.dragMode === 'linear') {
        const k = 0.2 * b.mass;
        const F = { x: -k*b.velocity.x, y: -k*b.velocity.y };
        Body.applyForce(b, b.position, F);
      } else if (state.dragMode === 'quadratic') {
        const rhoC = 0.02; // lumped constant for demo
        const v = b.velocity, vmag = Math.hypot(v.x, v.y) || 1e-6;
        const F = { x: -rhoC * vmag * v.x, y: -rhoC * vmag * v.y };
        Body.applyForce(b, b.position, F);
      }
    }
    // external forces
    for (let i=appliedForces.length-1; i>=0; i--) {
      const f = appliedForces[i];
      if (f.mode === 'impulse') {
        Body.applyForce(f.body, f.point || f.body.position, { x: f.Fx, y: f.Fy });
        appliedForces.splice(i,1);
      } else if (f.mode === 'constant') {
        Body.applyForce(f.body, f.point || f.body.position, { x: f.Fx, y: f.Fy });
        if (f.duration != null) {
          f.timeLeft -= dt;
          if (f.timeLeft <= 0) appliedForces.splice(i,1);
        }
      }
    }
  }
  function addAppliedForce(f) { appliedForces.push(f); }

  function step(dt) { applyForces(dt); Matter.Engine.update(engine, 1000/60); sampleTrails(); }

  // Picking / selection
  function pick(x, y) {
    for (let i = state.bodies.length - 1; i >= 0; i--) {
      const b = state.bodies[i];
      if (Matter.Bounds.contains(b.bounds, {x,y}) && Matter.Vertices.contains(b.vertices, {x,y})) return b;
    }
    return null;
  }
  function select(b) { state.selected = b; window.dispatchEvent(new CustomEvent('selection', { detail: b })); }

  function setGravity(gx, gy) { state.g = gy; }
  function setDragMode(mode) { state.dragMode = mode; }

  function reset() {
    Composite.allBodies(world).forEach(b => { if (!b.isStatic) World.remove(world, b); });
    state.bodies = []; state.constraints.forEach(c=>World.remove(world,c)); state.constraints=[];
    trailsClear();
  }

  // Trails
  function trailsClear() { state.trails.clear(); state.trailTick = 0; }
  function sampleTrails() {
    if (!state.showTrails) return;
    state.trailTick++;
    if (state.trailTick % state.trailEvery !== 0) return;
    for (const b of state.bodies) {
      if (!state.trails.has(b)) state.trails.set(b, []);
      const list = state.trails.get(b);
      list.push({ x: b.position.x, y: b.position.y });
      if (list.length > 400) list.shift();
    }
  }

  // Drawing
  function draw(ctx) {
    // constraints
    ctx.strokeStyle = '#88a'; ctx.lineWidth = 2;
    state.constraints.forEach(c => {
      const a = c.bodyA ? Vector.add(c.bodyA.position, c.pointA) : c.pointA;
      const b = c.bodyB ? Vector.add(c.bodyB.position, c.pointB) : c.pointB;
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    });
    // trails
    if (state.showTrails) {
      ctx.strokeStyle = '#32536d'; ctx.lineWidth = 1;
      state.trails.forEach(list => {
        if (list.length < 2) return;
        ctx.beginPath();
        for (let i=0;i<list.length;i++) { const p = list[i]; if (i===0) ctx.moveTo(p.x,p.y); else ctx.lineTo(p.x,p.y); }
        ctx.stroke();
      });
    }
    // bodies
    Composite.allBodies(world).forEach(body => {
      ctx.beginPath();
      body.vertices.forEach((v,i)=> i?ctx.lineTo(v.x,v.y):ctx.moveTo(v.x,v.y));
      ctx.closePath();
      ctx.fillStyle = body.isStatic ? '#1b2530' : '#243244'; ctx.strokeStyle = '#4e6a86';
      ctx.fill(); ctx.stroke();

      if (state.showVectors && !body.isStatic) {
        // velocity vector
        ctx.beginPath(); ctx.moveTo(body.position.x, body.position.y);
        ctx.lineTo(body.position.x + body.velocity.x*10, body.position.y + body.velocity.y*10);
        ctx.strokeStyle = '#6ad4ff'; ctx.stroke();
        // acceleration approx: (force / m) — use gravity vector for display
        const ay = state.g; const ax = 0;
        ctx.beginPath(); ctx.moveTo(body.position.x, body.position.y);
        ctx.lineTo(body.position.x + ax*5, body.position.y + ay*5);
        ctx.strokeStyle = '#b6ff7a'; ctx.stroke();
      }
    });
    if (state.selected) {
      const b = state.selected;
      ctx.beginPath(); b.vertices.forEach((v,i)=> i?ctx.lineTo(v.x,v.y):ctx.moveTo(v.x,v.y)); ctx.closePath();
      ctx.strokeStyle = '#5ab0ff'; ctx.lineWidth = 3; ctx.stroke(); ctx.lineWidth = 1;
    }
  }

  function computeEnergies() {
    let KE=0, PE=0;
    for (const b of state.bodies) {
      if (b.isStatic) continue;
      const v2 = b.velocity.x*b.velocity.x + b.velocity.y*b.velocity.y;
      KE += 0.5 * b.mass * v2;
      const dy = (state.zeroPEy - b.position.y) / state.ppm;
      PE += b.mass * state.g * dy;
    }
    return { KE, PE, TE: KE+PE };
  }

  function exportScene() {
    const data = {
      g: state.g, dragMode: state.dragMode,
      bodies: state.bodies.map(b => ({ label:b.label, x:b.position.x, y:b.position.y, angle:b.angle, mass:b.mass, restitution:b.restitution, friction:b.friction, frictionStatic:b.frictionStatic, isStatic:b.isStatic, shape:b.circleRadius?{type:'circle', r:b.circleRadius}:{type:'box', w:b.bounds.max.x-b.bounds.min.x, h:b.bounds.max.y-b.bounds.min.y } }))
    };
    const blob = new Blob([JSON.stringify(data,null,2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download='scene.json'; a.click();
  }

  // Templates
  const templates = {
    freefall() {
      reset();
      for (let i=0;i<4;i++) addCircle(300+i*60, 200, 18, 1+i*0.5);
    },
    projectile() {
      reset();
      const ball = addCircle(200, 600, 18, 1);
      Body.setVelocity(ball, { x: 12, y: -18 });
      addInclined(1000, 720, 600, 14, 0.02);
    },
    collision() {
      reset();
      const a = addBox(400, 600, 80, 40, 2); Body.setVelocity(a, { x: 6, y: 0 });
      const b = addBox(800, 600, 80, 40, 2, { restitution: 0.8 });
    },
    shm() {
      reset();
      const anchor = addCircle(500, 200, 6, 100, { isStatic:true });
      const bob = addCircle(700, 200, 18, 1);
      addSpring(anchor, bob, { k: 200, length: 200, damping: 5 });
    }
  };

  // API
  return {
    addCircle, addBox, addInclined, addPendulum, addSpring,
    setMass, pick, select, setGravity, setDragMode,
    step, reset, draw, computeEnergies, exportScene, addAppliedForce,
    get world(){return world;}, get state(){return state;}, templates
  };
}
