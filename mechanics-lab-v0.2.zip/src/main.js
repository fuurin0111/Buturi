import { createEngine } from './physics/engine.js';
import { buildPalette } from './ui/palette.js';
import { buildProps } from './ui/props.js';
import { setupGraphs } from './ui/graphs.js';
import { setupTools } from './ui/tools.js';

const canvas = document.getElementById('world');
const ctx = canvas.getContext('2d');
const zoomHud = document.getElementById('zoomHud');
const gridToggle = document.getElementById('gridToggle');
const graphsPane = document.getElementById('graphs');
const toggleGraphsBtn = document.getElementById('toggleGraphs');
const gravityInput = document.getElementById('gravity');
const vectorsToggle = document.getElementById('vectorsToggle');
const trailsToggle = document.getElementById('trailsToggle');
const trailRate = document.getElementById('trailRate');
const timeDisplay = document.getElementById('timeDisplay');
const playPauseBtn = document.getElementById('playPause');
const stepBtn = document.getElementById('step');
const resetBtn = document.getElementById('reset');
const speedSelect = document.getElementById('speed');
const langSelect = document.getElementById('lang');
const menuTemplates = document.getElementById('menuTemplates');
const templatesDropdown = document.getElementById('templatesDropdown');
const menuExport = document.getElementById('menuExport');
const exportDropdown = document.getElementById('exportDropdown');
const dragMode = document.getElementById('dragMode');

const PIXELS_PER_METER = 80;
const engine = createEngine(canvas, { pixelsPerMeter: PIXELS_PER_METER });

let running = true;
let simSpeed = 1;
let zoom = 1;
let t = 0;

// i18n (lightweight)
const i18n = {
  en: await (await fetch('./src/i18n/en.json')).json(),
  ja: await (await fetch('./src/i18n/ja.json')).json(),
};
let lang = 'en';
langSelect.addEventListener('change', () => {
  lang = langSelect.value;
  document.title = i18n[lang].title;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (i18n[lang][key]) el.textContent = i18n[lang][key];
  });
});
document.title = i18n[lang].title;

buildPalette(engine);
buildProps(engine);
const graphs = setupGraphs(engine);
setupTools(engine); // register tools & interactions

// Toolbar
gridToggle.addEventListener('change', () => {
  canvas.classList.toggle('no-grid', !gridToggle.checked);
});
toggleGraphsBtn.addEventListener('click', () => {
  const closed = graphsPane.classList.toggle('collapsed');
  toggleGraphsBtn.textContent = closed ? '▲' : '▼';
});
gravityInput.addEventListener('input', () => engine.setGravity(0, parseFloat(gravityInput.value)));
vectorsToggle.addEventListener('change', () => engine.state.showVectors = vectorsToggle.checked);
trailsToggle.addEventListener('change', () => engine.state.showTrails = trailsToggle.checked);
trailRate.addEventListener('input', () => engine.state.trailEvery = parseInt(trailRate.value,10));
playPauseBtn.addEventListener('click', () => running = !running);
speedSelect.addEventListener('change', () => { simSpeed = parseFloat(speedSelect.value.replace('x','')); });
dragMode.addEventListener('change', () => engine.setDragMode(dragMode.value));

// Menus
function hookDropdown(button, dropdown) {
  button.addEventListener('click', () => dropdown.hidden = !dropdown.hidden);
  document.addEventListener('click', (e) => {
    if (!button.contains(e.target) && !dropdown.contains(e.target)) dropdown.hidden = true;
  });
}
hookDropdown(menuTemplates, templatesDropdown);
hookDropdown(menuExport, exportDropdown);

templatesDropdown.addEventListener('click', (e) => {
  if (e.target.tagName !== 'BUTTON') return;
  const type = e.target.dataset.template;
  engine.templates[type]?.(); t = 0; graphs.reset(); 
});

document.getElementById('exportCSV').addEventListener('click', () => graphs.exportCSV());
document.getElementById('exportScene').addEventListener('click', () => engine.exportScene());

// Zoom & pan
let pan = {x:0, y:0};
let isPanning = false, last = {x:0, y:0};
canvas.addEventListener('mousedown', (e) => { if (e.button !== 0) { isPanning = true; last.x = e.clientX; last.y = e.clientY; }});
window.addEventListener('mouseup', () => isPanning = false);
window.addEventListener('mousemove', (e) => {
  if (isPanning) { pan.x += e.clientX - last.x; pan.y += e.clientY - last.y; last.x = e.clientX; last.y = e.clientY; }
});
canvas.addEventListener('wheel', (e) => { e.preventDefault(); const factor = Math.exp(-e.deltaY * 0.001); zoom = Math.max(0.1, Math.min(10, zoom * factor)); zoomHud.textContent = Math.round(zoom*100) + '%';}, { passive: false });

// Selection & spawn via canvas double-click handled in palette/tools

// Render loop
function render() {
  const w = canvas.width, h = canvas.height;
  ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,w,h);
  ctx.setTransform(zoom,0,0,zoom,pan.x,pan.y);
  engine.draw(ctx);
  timeDisplay.textContent = `t = ${t.toFixed(2)} s`;
  graphs.draw();
}

let lastTime = performance.now();
function loop(now) {
  const dt = (now - lastTime) / 1000; lastTime = now;
  if (running) {
    const steps = Math.max(1, Math.round(simSpeed));
    for (let i=0;i<steps;i++) { engine.step(1/60); t += 1/60; graphs.sample(t); }
  }
  render();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

// Keyboard
window.addEventListener('keydown', (e) => {
  if (e.code === 'Space') { e.preventDefault(); running = !running; }
  if (e.code === 'KeyR' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); engine.templates.freefall(); t=0; }
  if (e.code === 'ArrowRight') { engine.step(1/60); t+=1/60; graphs.sample(t); }
});

window.engine = engine;
